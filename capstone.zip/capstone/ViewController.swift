import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var dailyTask: UILabel!
    
    private var tasks: [Task] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchJSON()
    }

    func fetchJSON() {
        guard let url = URL(string: "https://raw.githubusercontent.com/sufiana26/ioscapstone/main/dailytasks.json") else {
            print("Invalid URL")
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    let decoded = try JSONDecoder().decode(TaskList.self, from: data)
                    DispatchQueue.main.async {
                        self.tasks = decoded.daily_decluttering_tasks
                        if let firstTask = self.tasks.first {
                            self.dailyTask.text = firstTask.task
                        }
                    }
                } catch {
                    print("Decoding error:", error)
                }
            } else if let error = error {
                print("Network error:", error)
            }
        }.resume()
    }
}
