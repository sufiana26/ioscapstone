//
//  Task.swift
//  capstone
//
//  Created by Sufian Azfar on 4/15/25.
//
import Foundation

struct TaskList: Codable {
    let daily_decluttering_tasks: [Task]
}

struct Task: Codable {
    let day: Int
    let task: String
}

