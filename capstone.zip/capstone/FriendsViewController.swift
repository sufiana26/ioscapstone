//
//  FriendsViewController.swift
//  capstone
//
//  Created by Sufian Azfar on 4/16/25.
//

import UIKit
class FriendsViewController: UIViewController, UITableViewDataSource {
    
    //array of friends
    private var friends = ["Sufian Azfar", "Taylor Swift", "Ada Lovelace", "Steve Jobs", "Marie Curie"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friends.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

     
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as! FriendCell

        // Get the friend associated table view row
        let friend = friends[indexPath.row]


        // Set the text on the labels
        cell.friendName.text = friend
        let streak = Int.random(in: 1...5)
        cell.friendStreak.text = "Streak: \(String(streak))"

        // Return the cell for use in the respective table view row
        return cell
    }
    

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        tableView.dataSource = self
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
